NOTES: THIS IS A DEMO VERSION WITH LIMITED GLYPHS WITH ONLY 2 STYLES (REGULAR AND THIN), 
TO GET THE FULL VERSION (54 STYLES) VISIT https://jetsmax.com/jx-tabe/

Jx Tabe is New techno sans serif typeface with a superfamily. inspired by robotic, mecha, 
and aesthetic machine - a font suited for future technology. This multi-purpose typeface will grab 
the reader's attention with its stylish and neat design. With 9 Weight + Italic and 2 Width Condensed 
and Expanded, With total of 54 styles, it's a timeless workhorse for many possible applications from 
branding to editorial.

What’s Included :
•	Jx Tabe (.OTF/.TTF/.WOFF/.WOFF2 + VARIABLE)
•	Web Font (WOFF/WOFF2)
•	Variable Font (Available in .TTF)
•	Works on PC & Mac
•	Simple installations
•	Accessible in Adobe Illustrator, Adobe Photoshop, Adobe InDesign, even work on Microsoft Word.
•	PUA Encoded Characters – Fully accessible without additional design software. Fonts include multilingual support 
for; Afrikaans, Albanian, Catalan, Danish, Dutch, English, French, Hungarian, Icelandic, Italian, Spanish, Portuguese, German, 
Swedish, Norwegian, Polish, Indonesian, Turkish, Zulu, Belarusian, Bulgarian, Kazakh, Kyrgyz, Macedonian, Montenegrin, Russian,
Serbian, Turkmen, Ukrainian, and Uzbek.


